/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.infinitelight.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.infinitelight.item.LeatherGlueItem;
import net.mcreator.infinitelight.item.FluorescentPowderItem;
import net.mcreator.infinitelight.InfiniteLightMod;

public class InfiniteLightModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(InfiniteLightMod.MODID);
	public static final DeferredItem<Item> FLUORESCENT_POWDER = REGISTRY.register("fluorescent_powder", FluorescentPowderItem::new);
	public static final DeferredItem<Item> LEATHER_GLUE = REGISTRY.register("leather_glue", LeatherGlueItem::new);
	public static final DeferredItem<Item> PURE_LAMP = block(InfiniteLightModBlocks.PURE_LAMP);
	public static final DeferredItem<Item> REDSTONE_PURE_LAMP = block(InfiniteLightModBlocks.REDSTONE_PURE_LAMP);

	// Start of user code block custom items
	// End of user code block custom items
	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), properties));
	}
}