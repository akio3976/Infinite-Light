package net.mcreator.infinitelight.item;

import net.minecraft.world.item.Item;

public class LeatherGlueItem extends Item {
	public LeatherGlueItem() {
		super(new Item.Properties());
	}
}