/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.infinitelight.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.Block;

import net.mcreator.infinitelight.block.RedstonePureLampBlock;
import net.mcreator.infinitelight.block.PureLampBlock;
import net.mcreator.infinitelight.block.LitRedstonePureLampBlock;
import net.mcreator.infinitelight.InfiniteLightMod;

public class InfiniteLightModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(InfiniteLightMod.MODID);
	public static final DeferredBlock<Block> PURE_LAMP = REGISTRY.register("pure_lamp", PureLampBlock::new);
	public static final DeferredBlock<Block> REDSTONE_PURE_LAMP = REGISTRY.register("redstone_pure_lamp", RedstonePureLampBlock::new);
	public static final DeferredBlock<Block> LIT_REDSTONE_PURE_LAMP = REGISTRY.register("lit_redstone_pure_lamp", LitRedstonePureLampBlock::new);
	// Start of user code block custom blocks
	// End of user code block custom blocks
}